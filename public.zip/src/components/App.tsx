// src/components/App.tsx
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../context/AuthContext';
import Login from '../auth/Login';
import Dashboard from '../dashboard/Dashboard';
import ProtectedRoute from '../auth/ProtectedRoute';
import UserPanel from './UserPanel';

const App = () => {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Ruta pública */}
          <Route path="/" element={<Login />} />
          
          {/* Rutas protegidas */}
          <Route element={<ProtectedRoute />}>
            <Route path="/dashboard" element={<Dashboard />} />
          </Route>
          
          {/* Ruta pública con parámetro */}
          <Route path="/u/:username" element={<UserPanel />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
};

export default App;